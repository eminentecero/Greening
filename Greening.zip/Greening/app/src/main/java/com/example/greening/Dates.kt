package com.example.greening

import java.text.SimpleDateFormat
import java.util.*

class Dates {
    var year = 0
    var month = 0
    var day = 0

    constructor(year:Int, month:Int, day:Int)
    {
        this.year = year
        this.month = month
        this.day = day
    }
    constructor(){

    }




}